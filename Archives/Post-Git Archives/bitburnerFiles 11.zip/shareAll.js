/** @param {NS} ns **/
export async function main(ns) {
    let target = ns.args[0];
    const homeBuffer = 16;

    
    if (!target) {
        ns.tprint("Usage: run shareAll.js SERVER");
        return;
    }

    if (!ns.serverExists(target)) {
        ns.tprint(`SERVER "${target}" is invalid`);
        return;
    }


    let script = "share.js";

    await ns.scp(script, target);
    
    let maxRam = ns.getServerMaxRam(target);
    let usedRam = ns.getServerUsedRam(target);
    let scriptRam = ns.getScriptRam(script);
    if (target === "home") {
        usedRam += homeBuffer;
    }
    let threads = Math.floor((maxRam - usedRam) / scriptRam);
    if(threads <= 0) {
        ns.tprint(`Not Enough Room`);
        return;
    }
        ns.tprint(`Running "${threads}" iterations of share.js on "${target}`);
        ns.exec(script, target, threads);
}