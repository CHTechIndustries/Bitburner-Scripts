/** @param {NS} ns **/
export async function main(ns) {
    const symbols = ns.stock.getSymbols();

    // State container (shared if needed)
    const state = {
        history: {},   // for momentum strategy
        positions: {}, // optional tracking
    };

    while (true) {
        const has4S = ns.stock.has4SData();

        for (const sym of symbols) {
            if (has4S) {
                await fourSStrategy(ns, sym, state);
            } else {
                await momentumStrategy(ns, sym, state);
            }
        }

        await ns.sleep(6000); // stock market tick
    }
}

/**
 * Momentum-based strategy (no 4S)
 */
async function momentumStrategy(ns, sym, state) {
    const price = ns.stock.getPrice(sym);

    // Initialize history
    if (!state.history[sym]) {
        state.history[sym] = [];
    }

    // Update history
    state.history[sym].push(price);
    if (state.history[sym].length > 50) {
        state.history[sym].shift();
    }

    // Not enough data yet
    if (state.history[sym].length < 20) return;

    const short = average(state.history[sym].slice(-5));
    const long = average(state.history[sym].slice(-20));

    const [shares, avgPrice] = ns.stock.getPosition(sym);

    // --- BUY LOGIC ---
    if (shares === 0 && short > long * 1.002) {
        // TODO: implement buy logic
    }

    // --- SELL LOGIC ---
    if (shares > 0) {
        const profit = (price - avgPrice) / avgPrice;

        if (short < long || profit > 0.05 || profit < -0.02) {
            // TODO: implement sell logic
        }
    }
}

/**
 * 4S-based strategy (uses forecast + volatility)
 */
async function fourSStrategy(ns, sym, state) {
    const forecast = ns.stock.getForecast(sym);
    const volatility = ns.stock.getVolatility(sym);
    const price = ns.stock.getPrice(sym);

    const [shares, avgPrice] = ns.stock.getPosition(sym);

    // --- BUY LOGIC ---
    if (shares === 0 && forecast > 0.6) {
        // TODO: implement buy logic
    }

    // --- SELL LOGIC ---
    if (shares > 0) {
        if (forecast < 0.5) {
            // TODO: implement sell logic
        }
    }
}

/**
 * Utility: average of array
 */
function average(arr) {
    return arr.reduce((a, b) => a + b, 0) / arr.length;
}