/** @param {NS} ns **/

/*
    homeHack.js

    Dynamically deploys a proportional hacking
    profile on HOME using serverMap.json

    Features:
    - Uses serverMap.json
    - Automatically selects best rooted money target
    - Uses weighted profile ratios
    - Dynamically calculates script RAM
    - Preserves HOME RAM buffer
    - Scales profile to available RAM
    - Fills leftover RAM with weaken threads

    Usage:
    run homeHack.js
*/

export async function main(ns) {

    // --------------------------------------------------
    // Constants
    // --------------------------------------------------

    const BUFFER = 32;
    const SERVER_MAP_FILE = "serverMap.json";

    // --------------------------------------------------
    // Script Definitions
    // --------------------------------------------------

    const scripts = {
        hack: "hack.js",
        grow: "grow.js",
        weaken: "weaken.js",
        share: "share.js"
    };

    // --------------------------------------------------
    // Profile Ratios
    // --------------------------------------------------

    const profile = {
        hack: 2,
        grow: 4,
        weaken: 6,
        share: 1
    };

    // --------------------------------------------------
    // Validate Scripts Exist
    // --------------------------------------------------

    for (const type in scripts) {

        if (!ns.fileExists(scripts[type], "home")) {

            ns.tprint(
                `ERROR: Missing script "${scripts[type]}"`
            );

            return;
        }
    }

    // --------------------------------------------------
    // Validate Server Map Exists
    // --------------------------------------------------

    if (!ns.fileExists(SERVER_MAP_FILE, "home")) {

        ns.tprint(
            `ERROR: Missing ${SERVER_MAP_FILE}`
        );

        return;
    }

    // --------------------------------------------------
    // Load Server Map
    // --------------------------------------------------

    const serverMap = JSON.parse(
        ns.read(SERVER_MAP_FILE)
    );

    // --------------------------------------------------
    // Find Best Rooted Money Target
    // --------------------------------------------------

    let target = null;
    let bestMoney = 0;

    for (const serverName in serverMap) {

        const server = serverMap[serverName];

        // Skip non-rooted servers
        if (!server.hasRoot) {
            continue;
        }

        // Skip servers with no money
        if (server.maxMoney <= 0) {
            continue;
        }

        // Highest max money wins
        if (server.maxMoney > bestMoney) {

            bestMoney = server.maxMoney;
            target = serverName;
        }
    }

    // --------------------------------------------------
    // Validate Target Found
    // --------------------------------------------------

    if (!target) {

        ns.tprint(
            "ERROR: No valid rooted money targets found."
        );

        return;
    }

    // --------------------------------------------------
    // Calculate Script RAM Usage
    // --------------------------------------------------

    const ramUsage = {};

    for (const type in scripts) {

        ramUsage[type] = ns.getScriptRam(
            scripts[type],
            "home"
        );

        if (ramUsage[type] <= 0) {

            ns.tprint(
                `ERROR: Could not determine RAM for "${scripts[type]}"`
            );

            return;
        }
    }

    // --------------------------------------------------
    // Calculate Full Profile Size
    // --------------------------------------------------

    let profileSize = 0;

    for (const type in profile) {

        profileSize +=
            ramUsage[type] * profile[type];
    }

    // --------------------------------------------------
    // HOME RAM Calculations
    // --------------------------------------------------

    const maxRam = ns.getServerMaxRam("home");
    const usedRam = ns.getServerUsedRam("home");

    const freeRam = maxRam - usedRam;
    const usableRam = freeRam - BUFFER;

    if (usableRam <= 0) {

        ns.tprint(
            `ERROR: Not enough free RAM after ${BUFFER}GB buffer.`
        );

        return;
    }

    // --------------------------------------------------
    // Calculate Number of Full Profiles
    // --------------------------------------------------

    const profileCount =
        Math.floor(usableRam / profileSize);

    if (profileCount <= 0) {

        ns.tprint(
            "ERROR: Not enough RAM for even one profile."
        );

        return;
    }

    // --------------------------------------------------
    // Scale Thread Counts
    // --------------------------------------------------

    const threads = {};

    for (const type in profile) {

        threads[type] =
            profile[type] * profileCount;
    }

    // --------------------------------------------------
    // Remaining RAM
    // --------------------------------------------------

    const deployedRam =
        profileCount * profileSize;

    const remainingRam =
        usableRam - deployedRam;

    // --------------------------------------------------
    // Extra Weaken Threads
    // --------------------------------------------------

    const extraWeakenThreads =
        Math.floor(
            remainingRam / ramUsage.weaken
        );

    // --------------------------------------------------
    // Deployment Summary
    // --------------------------------------------------

    ns.tprint("========================================");
    ns.tprint("HOME PROFILE DEPLOYMENT");
    ns.tprint("========================================");

    ns.tprint(`Target: ${target}`);
    ns.tprint(
        `Target Max Money: ${ns.formatNumber(bestMoney)}`
    );

    ns.tprint("");

    ns.tprint(
        `Max RAM:       ${maxRam.toFixed(2)} GB`
    );

    ns.tprint(
        `Used RAM:      ${usedRam.toFixed(2)} GB`
    );

    ns.tprint(
        `Free RAM:      ${freeRam.toFixed(2)} GB`
    );

    ns.tprint(
        `Buffer:        ${BUFFER.toFixed(2)} GB`
    );

    ns.tprint(
        `Usable RAM:    ${usableRam.toFixed(2)} GB`
    );

    ns.tprint("");

    ns.tprint(
        `Profile Size:  ${profileSize.toFixed(2)} GB`
    );

    ns.tprint(
        `Profile Count: ${profileCount}`
    );

    ns.tprint("");

    ns.tprint("Threads:");

    for (const type in threads) {

        ns.tprint(
            `  ${type.padEnd(8)} ${threads[type]}`
        );
    }

    ns.tprint(
        `  extraWeak ${extraWeakenThreads}`
    );

    ns.tprint("");

    ns.tprint(
        `Profile RAM:   ${deployedRam.toFixed(2)} GB`
    );

    ns.tprint(
        `Remaining RAM: ${remainingRam.toFixed(2)} GB`
    );

    ns.tprint("========================================");

    // --------------------------------------------------
    // Deploy Scripts
    // --------------------------------------------------

    // HACK
    if (threads.hack > 0) {

        ns.exec(
            scripts.hack,
            "home",
            threads.hack,
            target
        );
    }

    // GROW
    if (threads.grow > 0) {

        ns.exec(
            scripts.grow,
            "home",
            threads.grow,
            target
        );
    }

    // WEAKEN
    if (threads.weaken > 0) {

        ns.exec(
            scripts.weaken,
            "home",
            threads.weaken,
            target
        );
    }

    // SHARE
    if (threads.share > 0) {

        ns.exec(
            scripts.share,
            "home",
            threads.share
        );
    }

    // EXTRA WEAKEN
    if (extraWeakenThreads > 0) {

        ns.exec(
            scripts.weaken,
            "home",
            extraWeakenThreads,
            target
        );
    }

    ns.tprint("Deployment complete.");
}