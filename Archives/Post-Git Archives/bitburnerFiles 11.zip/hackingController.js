/** @param {NS} ns **/
import { deploy } from "./deployer.js";

export async function main(ns) {

    const target = ns.args[0];


    if (!target) {
        ns.tprint("Usage: run hackingController.js SERVER");
        return;
    }

    if (!ns.serverExists(target)) {
        ns.tprint(`SERVER "${target}" is invalid`);
        return;
    }
    const serverMap = JSON.parse(ns.read("serverMap.json"));
    const serverData = serverMap[target];
    const maxMoney = serverData?.maxMoney ?? 0;

    // ----------------------------
    // WORKLOAD PROFILE (THIS IS THE CORE IDEA)
    // ----------------------------
    let profile = [
        { script: "hack.js",  threads: 1 }, // hack
        { script: "grow.js",   threads: 2 }, // grow
        { script: "weaken.js", threads: 5 },  // stabilize / XP
        { script: "share.js", threads: -1 } //share the rest
    ];

    if(maxMoney < 1) {
        profile = [
            { script: "weaken.js", threads: 8}, //xp
            { script: "share.js", threads: -1} //share the rest
        ]
    };

    const results = [];

    for (const job of profile) {
        const result = deploy(ns, {
            script: job.script,
            target: target,
            threads: job.threads,
            fallback: true
        });

        results.push(result?.message ?? "deploy failed");
    }

    ns.tprint(`[${target}] ${results.join(" | ")}`);
}