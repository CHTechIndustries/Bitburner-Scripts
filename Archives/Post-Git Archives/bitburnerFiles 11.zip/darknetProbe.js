/** @param {NS} ns */
export async function main(ns) {
	ns.dnet.probe();
}