/** @param {NS} ns */
export async function main(ns) {
	let serverNum = 0;
	const baseName = "shareServer";
	let serverName = baseName + serverNum;
	while(true) {
		serverNum++;
		serverName = baseName + serverNum;
		await ns.tprint(`Derived server "${serverName}"`);

		if(serverNum == 5) {
			return;
		}
	}
}